Ashes Bridge 0.1

Firefox test:
1. Unzip this folder.
2. Open about:debugging in Firefox.
3. Choose "This Firefox".
4. Click "Load Temporary Add-on".
5. Choose manifest.json.
6. Open https://www.ashesstack.cloud/workspace and refresh it.
7. Open a ChatGPT / Claude / Gemini chat. Click the small "A" bubble.

How it works:
- "Use project brain" injects the active Ashes project context into the AI prompt box and links that tab.
- Once linked, the visible conversation is kept in the active Ashes project brain.
- "Save this chat" performs an immediate manual sync.
- The extension never asks for your AI password or session cookie.
