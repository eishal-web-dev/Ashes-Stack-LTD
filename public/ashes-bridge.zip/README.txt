ASHES BRIDGE 0.2

Test build:
Firefox -> about:debugging -> This Firefox -> Load Temporary Add-on -> manifest.json

Once loaded:
1. Open https://www.ashesstack.cloud/workspace
2. Click Connect Ashes once.
3. Use Continue in ChatGPT / Claude / Gemini. The shared brain is inserted automatically and supported chats sync back to the active project.

Public release goal: browser-store installation so setup is one normal Install click.
